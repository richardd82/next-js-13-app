
export default function test() {
    console.log('Hola desde Test.js')
  return 'Hola desde Test.js'
}